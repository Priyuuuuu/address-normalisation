import streamlit as st
import requests

def fetch_address(api_key, address):
    base_url = "https://geocode.search.hereapi.com/v1/geocode"

    # Parameters for the API request
    params = {
        'q': address,
        'apiKey': api_key
    }

    # Send the request
    response = requests.get(base_url, params=params)

    # Check if the request was successful
    if response.status_code == 200:
        data = response.json()
        if data['items']:
            # Extract the formatted address and coordinates from the response
            item = data['items'][0]
            formatted_address = item['address']['label']
            lat = item['position']['lat']
            lng = item['position']['lng']

            # Generate the location link
            location_link = f"https://www.google.com/maps?q={lat},{lng}"

            return formatted_address, lat, lng, location_link
        else:
            return "Address not found or could not be resolved.", None, None, None
    else:
        return "Failed to connect to the API.", None, None, None

# Streamlit app
def main():
    st.title("Address Geocoding with HERE API")

    # HERE API credentials (replace with your actual API key)
    api_key = "t1GJ-gWj-Xy01EZXf1uLxZ7yOFwRttJpChZLRMqtTAo"

    # User input for the address
    address = st.text_input("Enter the address to fetch")

    # Check if both API key and address are provided
    if st.button("Fetch Address"):
        if api_key and address:
            # Fetch and display the corrected address and location details
            corrected_address, lat, lng, location_link = fetch_address(api_key, address)

            st.subheader("Results")
            st.write("Corrected Address:", corrected_address)

            if lat and lng:
                st.write("Latitude:", lat)
                st.write("Longitude:", lng)
                st.write(f"[View Location on Google Maps]({location_link})")
            else:
                st.write("No location details available.")
        else:
            st.error("Please provide both an API key and an address.")

if __name__ == "__main__":
    main()
